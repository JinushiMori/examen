﻿namespace MatveevE
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.vistavka_sobaki_MatveevEDataSet = new MatveevE.Vistavka_sobaki_MatveevEDataSet();
            this.sobakiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sobakiTableAdapter = new MatveevE.Vistavka_sobaki_MatveevEDataSetTableAdapters.SobakiTableAdapter();
            this.klichkaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.porodaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vozrastDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomerdokumentaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.roditeliklichkiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.khozyainkodDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kodsobakiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataprivikiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.khozyainBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.khozyainTableAdapter = new MatveevE.Vistavka_sobaki_MatveevEDataSetTableAdapters.KhozyainTableAdapter();
            this.tableAdapterManager = new MatveevE.Vistavka_sobaki_MatveevEDataSetTableAdapters.TableAdapterManager();
            this.khozyainDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vistavka_sobaki_MatveevEDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sobakiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.khozyainBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.khozyainDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.klichkaDataGridViewTextBoxColumn,
            this.porodaDataGridViewTextBoxColumn,
            this.vozrastDataGridViewTextBoxColumn,
            this.nomerdokumentaDataGridViewTextBoxColumn,
            this.roditeliklichkiDataGridViewTextBoxColumn,
            this.khozyainkodDataGridViewTextBoxColumn,
            this.kodsobakiDataGridViewTextBoxColumn,
            this.dataprivikiDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.sobakiBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(-2, -1);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(843, 220);
            this.dataGridView1.TabIndex = 0;
            // 
            // vistavka_sobaki_MatveevEDataSet
            // 
            this.vistavka_sobaki_MatveevEDataSet.DataSetName = "Vistavka_sobaki_MatveevEDataSet";
            this.vistavka_sobaki_MatveevEDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sobakiBindingSource
            // 
            this.sobakiBindingSource.DataMember = "Sobaki";
            this.sobakiBindingSource.DataSource = this.vistavka_sobaki_MatveevEDataSet;
            // 
            // sobakiTableAdapter
            // 
            this.sobakiTableAdapter.ClearBeforeFill = true;
            // 
            // klichkaDataGridViewTextBoxColumn
            // 
            this.klichkaDataGridViewTextBoxColumn.DataPropertyName = "Klichka";
            this.klichkaDataGridViewTextBoxColumn.HeaderText = "Klichka";
            this.klichkaDataGridViewTextBoxColumn.Name = "klichkaDataGridViewTextBoxColumn";
            // 
            // porodaDataGridViewTextBoxColumn
            // 
            this.porodaDataGridViewTextBoxColumn.DataPropertyName = "Poroda";
            this.porodaDataGridViewTextBoxColumn.HeaderText = "Poroda";
            this.porodaDataGridViewTextBoxColumn.Name = "porodaDataGridViewTextBoxColumn";
            // 
            // vozrastDataGridViewTextBoxColumn
            // 
            this.vozrastDataGridViewTextBoxColumn.DataPropertyName = "Vozrast";
            this.vozrastDataGridViewTextBoxColumn.HeaderText = "Vozrast";
            this.vozrastDataGridViewTextBoxColumn.Name = "vozrastDataGridViewTextBoxColumn";
            // 
            // nomerdokumentaDataGridViewTextBoxColumn
            // 
            this.nomerdokumentaDataGridViewTextBoxColumn.DataPropertyName = "Nomer_dokumenta";
            this.nomerdokumentaDataGridViewTextBoxColumn.HeaderText = "Nomer_dokumenta";
            this.nomerdokumentaDataGridViewTextBoxColumn.Name = "nomerdokumentaDataGridViewTextBoxColumn";
            // 
            // roditeliklichkiDataGridViewTextBoxColumn
            // 
            this.roditeliklichkiDataGridViewTextBoxColumn.DataPropertyName = "Roditeli(klichki)";
            this.roditeliklichkiDataGridViewTextBoxColumn.HeaderText = "Roditeli(klichki)";
            this.roditeliklichkiDataGridViewTextBoxColumn.Name = "roditeliklichkiDataGridViewTextBoxColumn";
            // 
            // khozyainkodDataGridViewTextBoxColumn
            // 
            this.khozyainkodDataGridViewTextBoxColumn.DataPropertyName = "Khozyain_kod";
            this.khozyainkodDataGridViewTextBoxColumn.HeaderText = "Khozyain_kod";
            this.khozyainkodDataGridViewTextBoxColumn.Name = "khozyainkodDataGridViewTextBoxColumn";
            // 
            // kodsobakiDataGridViewTextBoxColumn
            // 
            this.kodsobakiDataGridViewTextBoxColumn.DataPropertyName = "Kod_sobaki";
            this.kodsobakiDataGridViewTextBoxColumn.HeaderText = "Kod_sobaki";
            this.kodsobakiDataGridViewTextBoxColumn.Name = "kodsobakiDataGridViewTextBoxColumn";
            // 
            // dataprivikiDataGridViewTextBoxColumn
            // 
            this.dataprivikiDataGridViewTextBoxColumn.DataPropertyName = "Data_priviki";
            this.dataprivikiDataGridViewTextBoxColumn.HeaderText = "Data_priviki";
            this.dataprivikiDataGridViewTextBoxColumn.Name = "dataprivikiDataGridViewTextBoxColumn";
            // 
            // khozyainBindingSource
            // 
            this.khozyainBindingSource.DataMember = "Khozyain";
            this.khozyainBindingSource.DataSource = this.vistavka_sobaki_MatveevEDataSet;
            // 
            // khozyainTableAdapter
            // 
            this.khozyainTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ClubTableAdapter = null;
            this.tableAdapterManager.ExpertTableAdapter = null;
            this.tableAdapterManager.KhozyainTableAdapter = this.khozyainTableAdapter;
            this.tableAdapterManager.RingTableAdapter = null;
            this.tableAdapterManager.SobakiTableAdapter = this.sobakiTableAdapter;
            this.tableAdapterManager.UchastkiTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = MatveevE.Vistavka_sobaki_MatveevEDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // khozyainDataGridView
            // 
            this.khozyainDataGridView.AutoGenerateColumns = false;
            this.khozyainDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.khozyainDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.khozyainDataGridView.DataSource = this.khozyainBindingSource;
            this.khozyainDataGridView.Location = new System.Drawing.Point(-2, 225);
            this.khozyainDataGridView.Name = "khozyainDataGridView";
            this.khozyainDataGridView.Size = new System.Drawing.Size(643, 220);
            this.khozyainDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "FIO";
            this.dataGridViewTextBoxColumn1.HeaderText = "FIO";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Data_rojdenia";
            this.dataGridViewTextBoxColumn2.HeaderText = "Data_rojdenia";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Seria_pasporta";
            this.dataGridViewTextBoxColumn3.HeaderText = "Seria_pasporta";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Nomer_pasporta";
            this.dataGridViewTextBoxColumn4.HeaderText = "Nomer_pasporta";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Gorod_rojdenia";
            this.dataGridViewTextBoxColumn5.HeaderText = "Gorod_rojdenia";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Kod_Khozyaina";
            this.dataGridViewTextBoxColumn6.HeaderText = "Kod_Khozyaina";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(712, 409);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Назад";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(843, 444);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.khozyainDataGridView);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form2";
            this.Text = "Участники";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vistavka_sobaki_MatveevEDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sobakiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.khozyainBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.khozyainDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private Vistavka_sobaki_MatveevEDataSet vistavka_sobaki_MatveevEDataSet;
        private System.Windows.Forms.BindingSource sobakiBindingSource;
        private Vistavka_sobaki_MatveevEDataSetTableAdapters.SobakiTableAdapter sobakiTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn klichkaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn porodaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vozrastDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomerdokumentaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn roditeliklichkiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn khozyainkodDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kodsobakiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataprivikiDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource khozyainBindingSource;
        private Vistavka_sobaki_MatveevEDataSetTableAdapters.KhozyainTableAdapter khozyainTableAdapter;
        private Vistavka_sobaki_MatveevEDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView khozyainDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.Button button1;
    }
}