﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MatveevE
{
    public class Data
    {
        public static string FileUsers = "Users.dat";
        public static List<User> Users;
        public static string Login { get; set; }
        public static string Password { get; set; }

        public static string Serialize()
        {
            string Text = "";

            foreach (var user in Data.Users)
            {
                Text += $"{user.Login}:{user.Password}\n";
            }

            return Text;
        }
    }
}