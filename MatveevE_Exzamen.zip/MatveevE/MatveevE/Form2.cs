﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MatveevE
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "vistavka_sobaki_MatveevEDataSet.Khozyain". При необходимости она может быть перемещена или удалена.
            this.khozyainTableAdapter.Fill(this.vistavka_sobaki_MatveevEDataSet.Khozyain);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "vistavka_sobaki_MatveevEDataSet.Sobaki". При необходимости она может быть перемещена или удалена.
            this.sobakiTableAdapter.Fill(this.vistavka_sobaki_MatveevEDataSet.Sobaki);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            frm1.Show();
            this.Hide();
        }
    }
}
