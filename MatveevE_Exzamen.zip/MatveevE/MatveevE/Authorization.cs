﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace MatveevE
{
    public partial class Authorization : Form
    {
        public Authorization()
        {
            InitializeComponent();
            LoadUsers();
        }

        public static void LoadUsers()
        {
            var Text = File.ReadAllText(Data.FileUsers);

            var users = new List<User>();

            using (StreamReader reader = new StreamReader(Data.FileUsers))
            {
                string line = "";
                while ((line = reader.ReadLine()) != null)
                {
                    string[] data = line.Split(':');
                    users.Add(new User(data[0], data[1]));
                }
            }

            Data.Users = users;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (var user in Data.Users)
            {
                if (user.Login == textBox1.Text && user.Password == textBox2.Text)
                {
                    Data.Login = textBox1.Text;
                    Data.Password = textBox2.Text;

                    this.Hide();
                    new Form1().Show();
                }
            }
        }
    }

    public class User
    {
        public string Login { get; set; }
        public string Password { get; set; }

        public User(string login, string password)
        {
            this.Login = login;
            this.Password = password;
        }
    }
}