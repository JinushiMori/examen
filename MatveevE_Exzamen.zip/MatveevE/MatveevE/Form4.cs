﻿using System;
using System.Windows.Forms;

namespace MatveevE
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void ringBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.ringBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.vistavka_sobaki_MatveevEDataSet);

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "vistavka_sobaki_MatveevEDataSet.Ring". При необходимости она может быть перемещена или удалена.
            this.ringTableAdapter.Fill(this.vistavka_sobaki_MatveevEDataSet.Ring);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            frm1.Show();
            this.Hide();
        }
    }
}
